
1
2
3
4
5
6
7
8
9
<?php
class FirstController extends Controller
{
	public function index()
	{
		return View::make('home');
	}
}
?>
