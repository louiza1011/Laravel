@extends('layouts.app')

@section('content')

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Whole Grain Website</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB9HIAGr35VhcU9NRPk1mYhDpRUOxlP1nw&callback=myMap"></script>
<link rel="stylesheet" type="text/css" href="../grain/stylesheet.css">

</head>
<body data-spy="scroll" data-target=".navbar" data-offset="50">

<div class="container-fluid secondary-nav-bar">
      <div class="container-fluid">
        <div class="row">

        <div class="firstnav">

  <a href="mailto:info@company.com" target="blank">info@company.com</a>&nbsp;&nbsp;&nbsp;
  <a href=#home class="lan"><strong>EN</strong></a>&nbsp;&nbsp;&nbsp;
  <a href=#home class="lan"><strong>GR</strong></a>
</div>
        </div>
      </div>
    </div>






<nav class="navbar navbar-inverse">
  <div class="container-fluid">
   <div class="navbar-header">
   <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>

    <a class="navbar-left" >
      <img src="..\grain\images\logo.png"  alt="Brand"  /></a>
     </div>


    <div class="collapse navbar-collapse" id="myNavbar" >
      <ul class="nav navbar-nav navbar-right" >
        <li><a href="#aboutus">ABOUT US</a></li>
        <li><a href="#products">PRODUCTS</a></li>
        <li><a href="#services">SERVICES</a></li>
        <li><a href="#contactus">CONTACT US</a></li>
        <li class="[ hidden-xs ]"><a href="#" class=" btn-circle btn-search" role="button"><span class="[ glyphicon glyphicon-search white ]" ></span></a></li>

      </ul>



    </div>
    </div>

</nav>

</br>


<div id="myCarousel" class="carousel slide" data-ride="carousel">



    <div class="carousel-inner" role="listbox">
      <div class="item active">
        <img src="..\grain\images\image1.png" alt="Image1">

      </div>


    </div>


</div>

<div id="aboutus" class="container-fluid">
<div style=" float:right; width:100%;" class="col-sm-6" >
   <img id="bg_img_" src="../grain/images/image2.png">

<div id="para_div" class="caption post-content">
  <h1>About Us</h1>
  <p style="color:#cca300;">Try to scroll this section and look at the navigation bar while scrolling! Try to scroll this section and look at the navigation bar while scrolling!</p></br>
  <p>Try to scroll this section and look at the navigation bar while scrolling! Try to scroll this section and look at the navigation bar while scrolling!</p></br>
   <p>Try to scroll this section and look at the navigation bar while scrolling! Try to scroll this section and look at the navigation bar while scrolling!</p></br>
    <p>Try to scroll this section and look at the navigation bar while scrolling! Try to scroll this section and look at the navigation bar while scrolling!</p>
  </div>
</div>
</div>





<div id="services" class="container-fluid">

  <h1>Services</h1>

<div class="row">
<div class="col-sm-12 col-md-12	col-lg-12 col-xl-12 dot" ><img src="..\grain\images\icon1.png" alt="Image"/>
<li></li> <li></li> <li></li> <li></li> <li></li> <li></li> <li></li> <li></li> <li></li> <li></li> <li></li> <li></li> <li></li> <li></li> <li></li> <li></li> <li></li>
<li></li> <li></li> <li></li> <li></li> <li></li> <li></li> <li></li> <li></li> <li></li> <li></li> <li></li>  <li></li> <li></li> <li></li> <li></li> <li></li> <li></li>
<img src="..\grain\images\icon2.svg" style="width: 102px; height:95px; float: right;"/></br>
</br></div>

    <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4" >Try to scroll this section and look at the navigation bar while scrolling! Try to scroll this section and look at the navigation bar while scrolling!</div>
    <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4"><ul><li>Try to scroll this section and look at the navigation bar while scrolling! Try to scroll this section and look at the navigation bar while scrolling!</li></div>
        <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4"><ul><li>Try to scroll this section and look at the navigation bar while scrolling! Try to scroll this section and look at the navigation bar while scrolling!</li></div>



   <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4" >Try to scroll this section and look at the navigation bar while scrolling! Try to scroll this section and look at the navigation bar while scrolling!</div>

    <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4"><ul><li>Try to scroll this section and look at the navigation bar while scrolling! Try to scroll this section and look at the navigation bar while scrolling!</li></div>
        <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4"><ul><li>Try to scroll this section and look at the navigation bar while scrolling! Try to scroll this section and look at the navigation bar while scrolling!</li></div>

   <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4" >Try to scroll this section and look at the navigation bar while scrolling! Try to scroll this section and look at the navigation bar while scrolling!
    </div>

    <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4"><ul><li>Try to scroll this section and look at the navigation bar while scrolling! Try to scroll this section and look at the navigation bar while scrolling!</li></div>
        <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4"><ul><li>Try to scroll this section and look at the navigation bar while scrolling! Try to scroll this section and look at the navigation bar while scrolling!</li></div>
           <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4" >Try to scroll this section and look at the navigation bar while scrolling! Try to scroll this section and look at the navigation bar while scrolling!
    </div>

    <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4"><ul><li>Try to scroll this section and look at the navigation bar while scrolling! Try to scroll this section and look at the navigation bar while scrolling!</li></div>
        <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4"><ul><li>Try to scroll this section and look at the navigation bar while scrolling! Try to scroll this section and look at the navigation bar while scrolling!</li></div>
</div>
</div>



<div id="products" class="container-fluid" >
  <h1>Products</h1>

<div class="container">
 <div class="row">
 <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4" style="padding-left:0px; padding-right:0px;">
  <p> Loren ipsum dolor si amet ipsum dolor si amet ipsum dolor Loren ipsum dolor si amet ipsum dolor si amet ipsum dolorLoren ipsum dolor si amet ipsum dolor si amet ipsum dolor Loren ipsum dolor si amet ipsum dolor si amet ipsum dolor</p>
  </div>

<div class="col-sm-4 col-md-4 col-lg-4 col-xl-4">
    				<div class="cuadro_intro_hover " style="background-color:#ffffff;">
						<p style="text-align:center; margin-top:20px;">
							<img src="..\grain\images\wheat.jpg" class="img-responsive" alt="">
						</p>
						<div class="caption">
							<div class="blur"></div>
							<div class="caption-text">
								<h3 style=" padding:15px; ">Wheat</h3>
								<p>Loren ipsum dolor si amet ipsum dolor si amet ipsum dolor Loren ipsum dolor si amet ipsum dolor si amet ipsum dolor</p>

							</div>
						</div>
					</div>
	    </div>
<div class="col-sm-4 col-md-4 col-lg-4 col-xl-4" style="padding-left:0px; padding-right:0px;">
    				<div class="cuadro_intro_hover " style="background-color:#ffffff;">
						<p style="text-align:center; margin-top:20px;">
							<img src="..\grain\images\barley.jpg" class="img-responsive" alt="">
						</p>
						<div class="caption">
							<div class="blur"></div>
							<div class="caption-text">
								<h3 style=" padding:15px;">Barley</h3>
								<p>Loren ipsum dolor si amet ipsum dolor si amet ipsum dolor Loren ipsum dolor si amet ipsum dolor si amet ipsum dolor</p>

							</div>
						</div>
					</div>
	    </div>
</div>
 <div class="row ">
 <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4 col-sm-offset-0 col-md-offset-0 col-lg-offset-0">
    				<div class="cuadro_intro_hover " style="background-color:#ffffff;">
						<p style="text-align:center; margin-top:20px;">
							<img src="..\grain\images\rye.jpg" class="img-responsive" alt="">
						</p>
						<div class="caption">
							<div class="blur"></div>
							<div class="caption-text">
								<h3 style=" padding:15px; ">Rye</h3>
								<p>Loren ipsum dolor si amet ipsum dolor si amet ipsum dolor Loren ipsum dolor si amet ipsum dolor si amet ipsum dolor</p>

							</div>
						</div>
					</div>
	    </div>

<div class="col-sm-4 col-md-4 col-lg-4 col-xl-4 col-sm-offset-0 col-md-offset-0 col-lg-offset-0">
    				<div class="cuadro_intro_hover " style="background-color:#ffffff;">
						<p style="text-align:center; margin-top:20px;">
							<img src="..\grain\images\beans.jpg" class="img-responsive" alt="">
						</p>
						<div class="caption">
							<div class="blur"></div>
							<div class="caption-text">
								<h3 style=" padding:15px; ">Beans</h3>
								<p>Loren ipsum dolor si amet ipsum dolor si amet ipsum dolor Loren ipsum dolor si amet ipsum dolor si amet ipsum dolor</p>

							</div>
						</div>
					</div>
	    </div>

<div class="col-sm-4 col-md-4 col-lg-4 col-xl-4 col-sm-offset-0 col-md-offset-0 col-lg-offset-0" style="padding-left:0px; padding-right:0px;">
    				<div class="cuadro_intro_hover " style="background-color:#ffffff;">
						<p style="text-align:center; margin-top:20px;">
							<img src="..\grain\images\peas.jpg" class="img-responsive" alt="">
						</p>
						<div class="caption">
							<div class="blur"></div>
							<div class="caption-text">
								<h3 style=" padding:15px;">Peas</h3>
								<p>Loren ipsum dolor si amet ipsum dolor si amet ipsum dolor Loren ipsum dolor si amet ipsum dolor si amet ipsum dolor</p>

							</div>
						</div>
					</div>
	    </div>


</div>


</div>
 <div class="row ">
<div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 ">
      <img  src="..\grain\images\logos.png"  class="center" alt="Brands" />
</div>
</div>
</div>
<div id="contactus" class="container-fluid" >


<div class="row">
    <div class="col-sm-6 col-md-6 col-lg-6 col-xl-6" style="background-color:#ecf3f0; padding-left:8%" >
    <h1>CONTACT US</h1>
    </br>
    <p> teset et eedgdehbg edjhgcvf jdhe dflh ldskhnzlk</p>
    </br>
    <p><span class="glyphicon glyphicon-map-marker"></span>&nbsp;&nbsp; Nullam aucto, Lectus Eget,1234,Country</p>
    <p><span class="glyphicon glyphicon-earphone"></span>&nbsp;&nbsp;+00 99 123 321</p>
    <p><span class="glyphicon glyphicon-print"></span>&nbsp;&nbsp;+00 22 123 321</p>
    <p><span class="glyphicon glyphicon-envelope"></span>&nbsp;&nbsp;info@company.com</p>
    </div>
    <div class="col-sm-6 col-md-6 col-lg-6 col-xl-6" style="padding-left:8%; padding-right:8%" >
    <h1>GET IN TOUCH</h1>
    <form  class="form-horizontal">

<fieldset>


<!-- Name input-->
<div class="form-group ">

  <div class="inner-addon right-addon">
      <i class="glyphicon glyphicon-user"></i>

  <input id="Name" name="Name" type="text" placeholder="Your name" class="form-control input-md" required="">

  </div>
  </div>
<!-- Email input-->
<div class="form-group ">

  <div class="inner-addon right-addon">
      <i class="glyphicon glyphicon-envelope"></i>
  <input id="email" name="email" type="text" placeholder="Email" class="form-control input-md" required="">

</div>
</div>


<!-- Textarea -->
<div class="form-group" >

  <div class="inner-addon right-addon">
      <i class="glyphicon glyphicon-comment"></i>
    <textarea class="form-control" id="Message" name="Message" rows="4">Message</textarea>

</div>
<div>
</fieldset>

<div class="row">
<button  type="submit" class="btn btn-default btn-block">Send a Message</button>



</form>

    </div>

</div>
</div>
</div>

<div id="googleMap" style="height:400px;width:100%;"></div>
<script>
function myMap() {
var myCenter = new google.maps.LatLng(41.878114, -87.629798);
var mapProp = {center:myCenter, zoom:12, scrollwheel:false, draggable:false, mapTypeId:google.maps.MapTypeId.ROADMAP};
var map = new google.maps.Map(document.getElementById("googleMap"),mapProp);
var marker = new google.maps.Marker({position:myCenter});
marker.setMap(map);
}
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBu-916DdpKAjTmJNIgngS6HL_kDIKU0aU&callback=myMap"></script>


<footer class="container-fluid text-center">
<div class="row">
  <div class="col-sm-4	col-md-4	col-lg-4	col-xl-4"><a class="navbar-brand" href="#">
      <img alt="Brand" src="..\grain\images\logo.png"/></a></div>

  <div class=" col-sm-4	col-md-4 col-lg-4 col-xl-4"> <p><strong> RECEIVE OUR NEWSLETTER</strong></p>
   <p>Lorem ipsum donec id elit non mi porta gravida at eget metus.</p>
    <div class="row">
   <div class="col-sm-6	col-md-6 col-lg-6 col-xl-6">

   <!-- Email input-->
<div class="form-group ">

<input id="email" name="email" type="text" placeholder="Email" class="form-control input-md" required="">


 </div>
 </div>
  <div class="col-sm-6	col-md-6 col-lg-6 col-xl-6">
 <button  type="submit" class="btn btn-default btn-block">SUBSCRIBE</button>
</div>
</div></div>
</br>
</br>
  <div class="col-sm-4	col-md-4 col-lg-4 col-xl-4">

 <a id="back-to-top" href="#" class="btn btn-primary btn-lg btn-circle  back-to-top" role="button"  data-toggle="tooltip" data-placement="left"><span class="glyphicon glyphicon-chevron-up"></span></a>
  </div>





</div>
  <p>© 2017, Company. All rights reserved | Developed by Louiza </p>
</footer>
<script>
$(document).ready(function(){
     $(window).scroll(function () {
            if ($(this).scrollTop() > 50) {
                $('#back-to-top').fadeIn();
            } else {
                $('#back-to-top').fadeOut();
            }
        });
        // scroll body to 0px on click
        $('#back-to-top').click(function () {
            $('#back-to-top').tooltip('hide');
            $('body,html').animate({
                scrollTop: 0
            }, 800);
            return false;
        });

        $('#back-to-top').tooltip('show');

});

</script>
</body>
</html>
@endsection
